<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Elephant Foods Company is your no.1 Spice Company with brands that will revolutionize the joy of flavour to life by thrilling our consumers taste buds all over the world.">
		<meta name="keywords" content="About Elephant Foods Company">
    <meta name="author" content="Nnanna Ephraim">
	
    <title>About Us</title>
	
    <link href="css/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' 
		type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href="css/webnet.css" rel="stylesheet">
		<link href="css/plugin_css/animate.css" rel="stylesheet">
		<link rel="icon" href="img/logo.png" type="image/x-icon">
  </head>

  <body id="page-top">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
	 <div class="container">
		<a class="navbar-brand js-scroll-trigger" href="index.php" title="Go to homepage"><img src="img/logo.png" style="width:75px" alt="Webnet"></a>
		<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" 
		  aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarResponsive">
		<ul class="navbar-nav ml-auto">
			<li class="nav-item"><a class="nav-link js-scroll-trigger" href="index.php">Home</a></li>
				<li class="nav-item"><a class="nav-link js-scroll-trigger" href="#">About</a></li>
				<li class="nav-item"><a class="nav-link js-scroll-trigger" href="gallery.php">Gallery</a></li>
			  <li class="nav-item"><a class="nav-link js-scroll-trigger" href="contact.php">Contact Us</a></li>
		</ul>
		</div>
	  </div>
	</nav>
	
	<section id="services">
				<h4 class="head"><marquee>About Elephant Foods Company <span style="font-size:13px">(Est - 2010)</span></marquee></h4>

			<div class="container">	
				<strong><p>Executive Summary</p></strong>
				<p> Elephant Foods Company is an emerging giant food condiments, herbs and spices producing company. 
					We are committed to remaining the best indigenous herbs and spice processing and packaging company in Nigeria with an exportable and standardized production process.<br>
					Considering the untapped opportunities in locally processed spices in Nigeria, we envisioned local processing, production and packaging of these spices since we grow most of the raw materials locally. 
					Our four years of operation has witnessed better development and with an assurance of getting to the top notch of our dream and to take the lead in the world of spices and herbs.</p>
				
				<strong><p>Company's Profile</p></strong>
				<p> Elephant Foods Company is a company that believes in customer satisfaction through standard and quality product and customer relationship friendly policy in conformance with the international/global best practices, 
					certification and approval thereby guaranteeing trust in the use of our products.<br>
					We are the producers of UBELEPHANT COCONUT SPICE and UBELEPHANT CURRY, with the intent to soon introduce more complementary condiments like Turmeric, Thyme, Rosemary Garlic and Ginger, Mixed spices, Pepper soup spice,Fish spice, Chicken Spice, Beef spice, Grinded Crayfish Powder and Chili etc. 
					Our brands irresistible aroma has promoted our company with remarkable goodwill from dealers and users of our products. Notwithstanding, this in line with our vision guarantees’ our reach to the top notch in committing our best towards bringing quality spices that will thrill our consumers taste bud and equally ensure a healthy meal.</p>

			<strong><p>History</p></strong>
			<p>We started in Dec 2010. <br>We discovered an untapped opportunity in locally produced spices and so 
				developed the passion to invest our idea and resources into spice production.<br></p>
			<p>We introduced our first brand UBElephant Coconut (7g sachet) prior to our official kick off with a manual sealing system which improved to an automated sealing system and got registered with NAFDAC in 25th Aug 2016. 
				The irresistible aroma of our coconut spice and the winning packaging enabled the brand to gain acceptance and helped our company with the necessary goodwill to sell more.<br>
				Our second brand UBElephant Curry comes in many forms 10g Sachet, 5g, 7g, 100g and 25g cannister cup. These were introduced in 2016 and till date is gradually gaining acceptance because of it’s irresistible aroma and taste in meals. Our sales in both brand has always witnessed tremendous annual increment in demand for our products.<br>
				As stated earlier, we started with a manual sealing process but currently running an automated production of these brands which has enabled us increase our production capacity.</p>

			<p><strong>Our Vision:</strong> Our vision is to be and remain the best Spice Company; with brands that will revolutionize the joy of flavour to life by thrilling our consumers’ taste buds all over the world.</p>
			<p><strong>Our Mission Statement:</strong> Being formidably the best through quality brands that are irresistible and the best in the market, dominating as the lead company with the major share of customers in the local and international spice market. We can manufacture to your standard quality and package with your trademark.</</p>

		</div>
    </section>
	
		<footer>
	  <div class="container-fluid">
	     <div class="row">
          <div class="col-md-12">
		    <div class="wow shake" data-wow-delay="1.0s">
              <a class="btn rounded-circle border border-secondary js-scroll-trigger circle footer" href="#page-top">
			  <i class="fa fa-lg fa-angle-double-up animated"></i></a>
            </div>
            <p class="footer">
			&copy; 2010 - <?php echo date("Y"); ?> Elephant Foods Company | Designed by <a class="ln" href="http://www.webnets.com.ng" target="_blank">Webnets</a>
			</p>
		  </div>  
	     </div>
	  </div>
	</footer>
	  
    <!--core js files-->
    <script src="js/jquery/jquery.min.js"></script>
	<script src="js/bootstrap/bootstrap.min.js"></script>
	<!--<script src="js/plugins/popper.min.js"></script>-->
	
	<!--plugins & custom js files-->
    <script src="js/plugins/jquery.easing.min.js"></script>
	<script src="js/plugins/wow.min.js"></script>
    <script src="js/webnet.min.js"></script>

  </body>
</html>
