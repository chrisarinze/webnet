<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Elephant Foods Company is your no.1 Spice Company with brands that will revolutionize the joy of flavour to life by thrilling our consumers taste buds all over the world.">
		<meta name="keywords" content="Contact Elephant Foods Company">
    <meta name="author" content="Nnanna Ephraim">
	
    <title>Contact Us</title>
	
    <link href="css/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' 
		type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href="css/webnet.css" rel="stylesheet">
		<link href="css/plugin_css/animate.css" rel="stylesheet">
		<link rel="icon" href="img/logo.png" type="image/x-icon">
  </head>

  <body id="page-top">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
	 <div class="container">
		<a class="navbar-brand js-scroll-trigger" href="index.php" title="Go to homepage"><img src="img/logo.png" style="width:75px" alt="Webnet"></a>
		<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" 
		  aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarResponsive">
		<ul class="navbar-nav ml-auto">
				<li class="nav-item"><a class="nav-link js-scroll-trigger" href="index.php">Home</a></li>
				<li class="nav-item"><a class="nav-link js-scroll-trigger" href="about.php">About</a></li>
				<li class="nav-item"><a class="nav-link js-scroll-trigger" href="gallery.php">Gallery</a></li>
			  <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#">Contact Us</a></li>
		</ul>
		</div>
	  </div>
	</nav>
	
	<section>
				<h4 class="head"><marquee>Get In Touch With Us</marquee></h4><br>

			<div class="container">	
			<div class="row">
			<div class="col-md-8">
			 <div class="bg-fair">
			   <form action="process.php" method="post">
			     <div class="row">
			      <div class="col-md-6">
					<div class="form-group">
						<label for="name">Name:</label>
						<div class="input-group">
						  <span class="input-group-addon"><i class="fa fa-edit"></i></span>
						<input type="text" class="form-control" name="contact_name" id="name" placeholder="Enter your name" maxlength="40" autocomplete="off" required></div>
					</div>
					<div class="form-group">
						<label for="email">Email Address:</label>
						<div class="input-group">
						  <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
						<input type="text" class="form-control" name="contact_email" id="email" placeholder="Enter your email" maxlength="40" autocomplete="off" required></div>
					</div>
					<div class="form-group">
                       <label for="subject">Subject</label>
                          <select id="subject" name="contact_subject" class="form-control" required>
                                <option value=""><--Choose One:--></option>
                                <option value="service">More Info about Us</option>
                                <option value="suggestions">Interested in Products</option>
                                <option value="product">Feedback and Suggestions</option>
                          </select>
                    </div>
				  </div>
				   <div class="col-md-6">
					<div class="form-group">
						<label for="message">Message</label>
						  <textarea name="contact_body" id="message" class="form-control no_resize" rows="12" cols="35" placeholder="Enter your message" maxlength="1000" required></textarea>
						  
					</div>
				   </div>
				   <div class="col-md-12 clearfix">
                      <button type="submit" class="btn btn-outline-info float-right" name="submit">Send Message</button>
                   </div>
				 </div>
				 </form>
			  </div>
			 </div>
			<div class="col-md-4">
			 <div class="widget-contact">
			  <address>
				  <strong>Phone Numbers:</strong><br>
				  <i class="fa fa-phone icon"></i> <span class="icon">(+234) 80394-78084</span> <br/>
				  <i class="fa fa-whatsapp icon"></i> <span class="icon">(+234) 80394-78084</span>
				</address>
				<address>
				  <strong>Email Address:</strong><br>
				  <i class="fa fa-envelope-open icon"></i> <a class="email" href="mailto:elephantfoods@gmail.com">Elephantfoods@gmail.com</a><br/>
				</address>
				<address>
				  <strong>Location(Factory):</strong><br>
				  <i class="fa fa-map-marker icon"></i> <span style="color:#bd3e14">#10 Ahamba, Ahukanma Avenue off Umuebeke, Porthacourt Road; Aba, Abia State Nigeria.</span><br/>
				</address>
				<address>
				  <strong>Location(Office):</strong><br>
				  <i class="fa fa-map-marker icon"></i> <span style="color:#bd3e14">#29 St. Phillip off Cemetary Road, Overrail Aba, Abia State - Nigeria.</span><br/>
				</address>	
				<address>
				  <strong>Social Networks:</strong><br>
                       	<ul class="company-social">
                            <li class="social-facebook"><a href="https://web.facebook.com/groups/136817426696582/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        </ul>	
				</address>
				
			 </div>
			</div>
		</div>
    </section>
	
		<footer>
	  <div class="container-fluid">
	     <div class="row">
          <div class="col-md-12">
		    <div class="wow shake" data-wow-delay="1.0s">
              <a class="btn rounded-circle border border-secondary js-scroll-trigger circle footer" href="#page-top">
			  <i class="fa fa-lg fa-angle-double-up animated"></i></a>
            </div>
            <p class="footer">
			&copy; 2010 - <?php echo date("Y"); ?> Elephant Foods Company | Designed by <a class="ln" href="http://www.webnets.com.ng" target="_blank">Webnets</a>
			</p>
		  </div>  
	     </div>
	  </div>
	</footer>
	  
    <!--core js files-->
    <script src="js/jquery/jquery.min.js"></script>
	<script src="js/bootstrap/bootstrap.min.js"></script>
	<!--<script src="js/plugins/popper.min.js"></script>-->
	
	<!--plugins & custom js files-->
    <script src="js/plugins/jquery.easing.min.js"></script>
	<script src="js/plugins/wow.min.js"></script>
    <script src="js/webnet.min.js"></script>

  </body>
</html>
