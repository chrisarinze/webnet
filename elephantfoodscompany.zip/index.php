<?php 
	//require connect.php
	require_once ('includes/connect.php');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Elephant Foods Company is your no.1 Spice Company with brands that will revolutionize the joy of flavour to life by thrilling our consumers taste buds all over the world.">
		<meta name="keywords" content="Elephant Foods Company, Spices, Seasonings, Food and Cooking Ingredients, Kitchen Stuffs.">
    <meta name="author" content="Nnanna Ephraim">
	
    <title>Elephant Foods Company - Home Page</title>
	
    <link href="css/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' 
		type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link href="css/webnet.min.css" rel="stylesheet">
		<link href="css/plugin_css/animate.css" rel="stylesheet">
		<link rel="icon" href="img/logo.png" type="image/x-icon">
  </head>

  <body id="page-top">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
	 <div class="container">
		<a class="navbar-brand js-scroll-trigger" href="#page-top"><img src="img/logo.png" style="width:75px" alt="Elephant Foods"></a>
		<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" 
		  aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
		  <span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarResponsive">
		<ul class="navbar-nav ml-auto">
			  <li class="nav-item"><a class="nav-link js-scroll-trigger" href="about.php">About</a></li>
				<li class="nav-item"><a class="nav-link js-scroll-trigger" href="#services">Our Products</a></li>
				<li class="nav-item"><a class="nav-link js-scroll-trigger" href="gallery.php">Gallery</a></li>
			  <li class="nav-item"><a class="nav-link js-scroll-trigger" href="contact.php">Contact Us</a></li>
		</ul>
		</div>
	  </div>
	</nav>
	
	<header class="masthead">
	  <div class="header-content">
	    <div class="header-content-inner">
		  <h1 id="homeHeading" class="sansserif">Elephant Foods Company</h1>
          <hr class="light">
          <p>Our vision is to be the best Spice Company; with brands that will revolutionize the joy of flavour to life by thrilling our consumers taste buds all over the world.</p>
		  <div class="wow swing" data-wow-delay="2.0s">
              <a class="btn rounded-circle border border-secondary js-scroll-trigger circle" href="#about">
		      <i class="fa fa-lg fa-angle-double-down"></i></a>
		  </div>
	    </div>
	  </div>
	</header>
	
	<section class="bg-primary" id="about">
      <div class="container-fluid">
						<div class="row">
							<div class="col-lg-9 mx-auto text-center">
						<div class="wow bounceInDown" data-wow-delay="0.6s">
								<h2 class="section-heading text-white">We've got what you need!</h2>
						</div>
						<hr class="light">
						<div class="wow fadeIn" data-wow-delay="0.2s">
								<p class="text-faded"><strong>Elephant Foods Company</strong>, is an emerging giant food condiments, herbs and spices producing company. 
										We are committed to been the best indigenous herbs and spice processing and packaging company in Nigeria with an exportable and standardized production process.</p> 
								<p class="text-faded">Elephant Foods Company is a company that believes in customer satisfaction through standard and quality product and customer relationship friendly policy in conformance with... <a class="more" href="about.php">Read More</a></p>
						</div>
						<div class="wow flash" data-wow-delay="2.0s">
									<a class="btn rounded-circle border border-secondary js-scroll-trigger circle" href="#services">
									<i class="fa fa-lg fa-angle-double-down"></i></a>
						</div>
						</div>
      </div>
    </section>
	
	<section id="services">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
		  <div class="wow bounceIn" data-wow-delay="0.8s">
            <h2 class="section-heading">Sample of Our Products</h2>
		   </div>
            <hr>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box">
			<div class="wow fadeIn" data-wow-delay="0.2s">
        <img src="img/efc3.png" style="width:75px">
			</div>
              <h4>Cocunut Flavour</h4>
              <p class="text-muted">Best for coconut rice.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box">
			<div class="wow fadeIn" data-wow-delay="0.3s">
				<img src="img/efc17.jpg" style="width:75px">
			</div>
              <h4>Curry Powder</h4>
              <p class="text-muted">Best for fried rice and noodles.</p>
            </div>
          </div>
		  <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box">
			<div class="wow fadeIn" data-wow-delay="0.5s">
				<img src="img/efc16.jpg" style="width:150px;height:90px;">
			</div>
              <h4>Herb Seasoning</h4>
              <p class="text-muted">Best for soup and stew.</p>
            </div>
          </div>
		  <div class="col-lg-3 col-md-6 text-center">
            <div class="service-box">
			<div class="wow fadeIn" data-wow-delay="0.4s">
				<img src="img/efc12.jpg" style="width:150px;height:90px;">
			</div>
              <h4>And Many More</h4>
              <p class="text-muted">Spices, herbs, flavours and lot more. <a class="email" href="gallery.php">Visit Our Gallery</a> for more.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
	
	<footer>
	  <div class="container-fluid">
	     <div class="row">
          <div class="col-md-12">
		    <div class="wow shake" data-wow-delay="1.0s">
              <a class="btn rounded-circle border border-secondary js-scroll-trigger circle footer" href="#page-top">
			  <i class="fa fa-lg fa-angle-double-up animated"></i></a>
            </div>
            <p class="footer">
			&copy; 2010 - <?php echo date("Y"); ?> Elephant Foods Company | Designed by <a class="ln" href="http://www.webnets.com.ng" target="_blank">Webnets</a>
			</p>
		  </div>  
	     </div>
	  </div>
	</footer>
	  
	  	
    <!--core js files-->
    <script src="js/jquery/jquery.min.js"></script>
	<script src="js/bootstrap/bootstrap.min.js"></script>
	<script src="js/plugins/popper.min.js"></script>
	
	<!--plugins & custom js files-->
    <script src="js/plugins/jquery.easing.min.js"></script>
	<script src="js/plugins/wow.min.js"></script>
    <script src="js/webnet.min.js"></script>

  </body>
</html>