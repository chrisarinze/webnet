<?php 
	$db_Server="localhost";
	$db_User="root";
	$db_Pass="";
	$db_Name="webnet";
	
?>