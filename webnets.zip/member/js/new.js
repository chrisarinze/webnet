(function($) {

	$('#login').click(function() {
	$(this).attr('disabled', true);
	});
	
})(jQuery);